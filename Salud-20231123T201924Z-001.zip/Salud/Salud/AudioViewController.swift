//
//  AudioViewController.swift
//  Salud
//
//  Created by Karla Espinosa on 21/11/23.
//

import UIKit
import AVFoundation

class AudioViewController: UIViewController {
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var playButton: UIButton!
    var player: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var url = Bundle.main.url(forResource: "eficiencia-energia", withExtension: "mp3")
        player = try! AVAudioPlayer(contentsOf: url!)
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(onSlideUpdate), userInfo: nil, repeats: true)
    }
    
    
    @IBAction func onButtonClick(_ sender: Any) {
        if(player.isPlaying == true){
            playButton.setTitle("Reproducir", for: .normal)
            player.pause()
        }else{
            playButton.setTitle("Pausar", for: .normal)
            player.play()
            slider.maximumValue = Float(player.duration)
        }
    }
    
    
    @IBAction func onSlideUpdate(_ sender: Any) {
        slider.value = Float(player?.currentTime ?? 0)
    }
    
    @IBAction func onSlideMove(_ sender: Any) {
        player.stop()
        player.currentTime = TimeInterval(slider.value)
        player.prepareToPlay()
        player.play()
    }
}
