//
//  EjerciciosViewController.swift
//  Salud
//
//  Created by Karla Espinosa on 19/11/23.
//

import UIKit
import AVFoundation

class EjerciciosViewController: UIViewController {
    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func HablaSiri(_ sender: Any) {
        
            let voice = AVSpeechSynthesisVoice(language: "en-AU")
            let tosay = AVSpeechUtterance(string: "Hola Hola Hola")
            tosay.volume = 1.0
            tosay.voice = voice
            let spk = AVSpeechSynthesizer()
            spk.speak(tosay)
        
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
