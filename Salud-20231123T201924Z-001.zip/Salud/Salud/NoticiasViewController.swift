//
//  ViewController.swift
//  Salud
//
//  Created by Karla Espinosa on 19/11/23.
//

import UIKit

class NoticiasViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

